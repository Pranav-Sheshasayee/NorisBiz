<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>New Oman Insurance: Login</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/normalize.min.css">
        <link rel="stylesheet" href="css/main.css">

        <!--[if lt IE 9]>
            <script src="//html5shiv.googlecode.com/svn/trunk/html5.js"></script>
            <script>window.html5 || document.write('<script src="js/vendor/html5shiv.js"><\/script>')</script>
        <![endif]-->

<style>
.ui-state-error{
	color:red;
	background-color:yellow;
}

#btnLogin{
  background-color:#4F81BD;
  color:white;
  width:160px;
  margin:5px 50px;
}
</style>
<script src="js/vendor/jquery-1.8.3.min.js" type="text/javascript"></script>
<script src="js/main.js" type="text/javascript"></script>
<script type="text/javascript">  
</script> 
</head>
    <body>
       
<header>
<div class="left">
<h3><strong>New Oman Insurance</strong> | Login</h3>
</div>

<div class="right">

</div>
</header>
<div class="clearfix"></div>
<div class="content">
<h2 class="blue left">LOGIN</h2>

<form class="form2">
<div class="loginbox">
            
	    <div id="login_message"></div>
	    
           
            	
                <fieldset>
                	<label>Login ID</label>
                    	<input type="text" name="username" id="username" class="inpute"/>
                  </fieldset>
                
               <fieldset>
               <label>Password</label>
                    	<input type="password" name="password" id="password"  class="inpute"/>
                </fieldset>
                
			  <fieldset>
                <input type="button" class="button"  id="btnLogin" value="Sign In"  />
			  </fieldset>
              
            
           

    </div><!--loginbox-->
    </form>
  </div>
 
<footer>

</footer>

       
    </body>
</html>
